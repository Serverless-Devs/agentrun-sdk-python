# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class CodeInterpreterSession(DaraModel):
    def __init__(
        self,
        code_interpreter_id: str = None,
        created_at: str = None,
        description: str = None,
        ended_at: str = None,
        exec_target_uri: str = None,
        id: str = None,
        interpreter: main_models.CodeInterpreter = None,
        name: str = None,
        session_id: str = None,
        session_timeout_seconds: int = None,
        status: str = None,
        updated_at: str = None,
    ):
        self.code_interpreter_id = code_interpreter_id
        self.created_at = created_at
        self.description = description
        self.ended_at = ended_at
        self.exec_target_uri = exec_target_uri
        self.id = id
        self.interpreter = interpreter
        self.name = name
        self.session_id = session_id
        # 会话超时时间（秒）
        self.session_timeout_seconds = session_timeout_seconds
        self.status = status
        self.updated_at = updated_at

    def validate(self):
        if self.interpreter:
            self.interpreter.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code_interpreter_id is not None:
            result['codeInterpreterId'] = self.code_interpreter_id

        if self.created_at is not None:
            result['createdAt'] = self.created_at

        if self.description is not None:
            result['description'] = self.description

        if self.ended_at is not None:
            result['endedAt'] = self.ended_at

        if self.exec_target_uri is not None:
            result['execTargetUri'] = self.exec_target_uri

        if self.id is not None:
            result['id'] = self.id

        if self.interpreter is not None:
            result['interpreter'] = self.interpreter.to_map()

        if self.name is not None:
            result['name'] = self.name

        if self.session_id is not None:
            result['sessionId'] = self.session_id

        if self.session_timeout_seconds is not None:
            result['sessionTimeoutSeconds'] = self.session_timeout_seconds

        if self.status is not None:
            result['status'] = self.status

        if self.updated_at is not None:
            result['updatedAt'] = self.updated_at

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('codeInterpreterId') is not None:
            self.code_interpreter_id = m.get('codeInterpreterId')

        if m.get('createdAt') is not None:
            self.created_at = m.get('createdAt')

        if m.get('description') is not None:
            self.description = m.get('description')

        if m.get('endedAt') is not None:
            self.ended_at = m.get('endedAt')

        if m.get('execTargetUri') is not None:
            self.exec_target_uri = m.get('execTargetUri')

        if m.get('id') is not None:
            self.id = m.get('id')

        if m.get('interpreter') is not None:
            temp_model = main_models.CodeInterpreter()
            self.interpreter = temp_model.from_map(m.get('interpreter'))

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('sessionId') is not None:
            self.session_id = m.get('sessionId')

        if m.get('sessionTimeoutSeconds') is not None:
            self.session_timeout_seconds = m.get('sessionTimeoutSeconds')

        if m.get('status') is not None:
            self.status = m.get('status')

        if m.get('updatedAt') is not None:
            self.updated_at = m.get('updatedAt')

        return self

