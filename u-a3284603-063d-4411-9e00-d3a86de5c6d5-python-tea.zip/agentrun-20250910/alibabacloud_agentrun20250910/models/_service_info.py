# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class ServiceInfo(DaraModel):
    def __init__(
        self,
        ai_service_config: main_models.AiServiceConfig = None,
        created_at: str = None,
        gateway_id: str = None,
        name: str = None,
        service_id: str = None,
        updated_at: str = None,
    ):
        self.ai_service_config = ai_service_config
        self.created_at = created_at
        self.gateway_id = gateway_id
        self.name = name
        self.service_id = service_id
        self.updated_at = updated_at

    def validate(self):
        if self.ai_service_config:
            self.ai_service_config.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.ai_service_config is not None:
            result['aiServiceConfig'] = self.ai_service_config.to_map()

        if self.created_at is not None:
            result['createdAt'] = self.created_at

        if self.gateway_id is not None:
            result['gatewayID'] = self.gateway_id

        if self.name is not None:
            result['name'] = self.name

        if self.service_id is not None:
            result['serviceID'] = self.service_id

        if self.updated_at is not None:
            result['updatedAt'] = self.updated_at

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('aiServiceConfig') is not None:
            temp_model = main_models.AiServiceConfig()
            self.ai_service_config = temp_model.from_map(m.get('aiServiceConfig'))

        if m.get('createdAt') is not None:
            self.created_at = m.get('createdAt')

        if m.get('gatewayID') is not None:
            self.gateway_id = m.get('gatewayID')

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('serviceID') is not None:
            self.service_id = m.get('serviceID')

        if m.get('updatedAt') is not None:
            self.updated_at = m.get('updatedAt')

        return self

