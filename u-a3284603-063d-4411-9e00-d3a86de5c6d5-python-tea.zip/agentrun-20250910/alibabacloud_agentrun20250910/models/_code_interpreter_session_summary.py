# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class CodeInterpreterSessionSummary(DaraModel):
    def __init__(
        self,
        code_interpreter_id: str = None,
        created_at: str = None,
        name: str = None,
        session_id: str = None,
        status: str = None,
    ):
        self.code_interpreter_id = code_interpreter_id
        self.created_at = created_at
        self.name = name
        self.session_id = session_id
        self.status = status

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code_interpreter_id is not None:
            result['codeInterpreterId'] = self.code_interpreter_id

        if self.created_at is not None:
            result['createdAt'] = self.created_at

        if self.name is not None:
            result['name'] = self.name

        if self.session_id is not None:
            result['sessionId'] = self.session_id

        if self.status is not None:
            result['status'] = self.status

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('codeInterpreterId') is not None:
            self.code_interpreter_id = m.get('codeInterpreterId')

        if m.get('createdAt') is not None:
            self.created_at = m.get('createdAt')

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('sessionId') is not None:
            self.session_id = m.get('sessionId')

        if m.get('status') is not None:
            self.status = m.get('status')

        return self

