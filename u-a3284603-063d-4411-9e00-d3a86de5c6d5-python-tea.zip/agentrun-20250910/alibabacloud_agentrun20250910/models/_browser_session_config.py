# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_agentrun20250910 import models as main_models
from darabonba.model import DaraModel

class BrowserSessionConfig(DaraModel):
    def __init__(
        self,
        initial_url: str = None,
        timeout: int = None,
        viewport: main_models.BrowserViewPort = None,
    ):
        self.initial_url = initial_url
        self.timeout = timeout
        self.viewport = viewport

    def validate(self):
        if self.viewport:
            self.viewport.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.initial_url is not None:
            result['initialUrl'] = self.initial_url

        if self.timeout is not None:
            result['timeout'] = self.timeout

        if self.viewport is not None:
            result['viewport'] = self.viewport.to_map()

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('initialUrl') is not None:
            self.initial_url = m.get('initialUrl')

        if m.get('timeout') is not None:
            self.timeout = m.get('timeout')

        if m.get('viewport') is not None:
            temp_model = main_models.BrowserViewPort()
            self.viewport = temp_model.from_map(m.get('viewport'))

        return self

