# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict, Any

from darabonba.model import DaraModel

class KnowledgeBase(DaraModel):
    def __init__(
        self,
        created_at: str = None,
        credential_name: str = None,
        description: str = None,
        knowledge_base_id: str = None,
        knowledge_base_name: str = None,
        last_updated_at: str = None,
        provider: str = None,
        provider_settings: Dict[str, Any] = None,
        retrieve_settings: Dict[str, Any] = None,
    ):
        self.created_at = created_at
        self.credential_name = credential_name
        self.description = description
        self.knowledge_base_id = knowledge_base_id
        self.knowledge_base_name = knowledge_base_name
        self.last_updated_at = last_updated_at
        self.provider = provider
        self.provider_settings = provider_settings
        self.retrieve_settings = retrieve_settings

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.created_at is not None:
            result['createdAt'] = self.created_at

        if self.credential_name is not None:
            result['credentialName'] = self.credential_name

        if self.description is not None:
            result['description'] = self.description

        if self.knowledge_base_id is not None:
            result['knowledgeBaseId'] = self.knowledge_base_id

        if self.knowledge_base_name is not None:
            result['knowledgeBaseName'] = self.knowledge_base_name

        if self.last_updated_at is not None:
            result['lastUpdatedAt'] = self.last_updated_at

        if self.provider is not None:
            result['provider'] = self.provider

        if self.provider_settings is not None:
            result['providerSettings'] = self.provider_settings

        if self.retrieve_settings is not None:
            result['retrieveSettings'] = self.retrieve_settings

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('createdAt') is not None:
            self.created_at = m.get('createdAt')

        if m.get('credentialName') is not None:
            self.credential_name = m.get('credentialName')

        if m.get('description') is not None:
            self.description = m.get('description')

        if m.get('knowledgeBaseId') is not None:
            self.knowledge_base_id = m.get('knowledgeBaseId')

        if m.get('knowledgeBaseName') is not None:
            self.knowledge_base_name = m.get('knowledgeBaseName')

        if m.get('lastUpdatedAt') is not None:
            self.last_updated_at = m.get('lastUpdatedAt')

        if m.get('provider') is not None:
            self.provider = m.get('provider')

        if m.get('providerSettings') is not None:
            self.provider_settings = m.get('providerSettings')

        if m.get('retrieveSettings') is not None:
            self.retrieve_settings = m.get('retrieveSettings')

        return self

